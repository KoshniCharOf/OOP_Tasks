package vignettes;

public class BusVin extends Vignette {

	public BusVin(Period period) {
		super(period);
		this.dayPrice = 9;
		this.stickTime = 20;
		this.color = "Bus-Pink";
	}




}
