package vignettes;

public class CarVin extends Vignette {

	public CarVin(Period period) {
		super(period);
		this.dayPrice = 5;
		this.stickTime = 5;
		this.color = "Car-Blue";
	}

	

}
