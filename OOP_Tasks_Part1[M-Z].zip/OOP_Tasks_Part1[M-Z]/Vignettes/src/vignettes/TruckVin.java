package vignettes;

public class TruckVin extends Vignette {

	public TruckVin(Period period) {
		super(period);
		this.dayPrice = 7;
		this.stickTime = 10;
		this.color = "Truck-Green";
		
	}

}
