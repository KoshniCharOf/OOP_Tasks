package vehicles;

public class Bus extends Vehicle {

	public Bus(String model) {
		super(model);
		this.type = 456;
	}

}
