package vehicles;

public class Truck extends Vehicle {

	public Truck(String model) {
		super(model);
		this.type = 789;
	}

}
