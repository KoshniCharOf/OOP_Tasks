/**
 * 
 */
package vehicles;

public class Car extends Vehicle {

	public Car(String model) {
		super(model);
		this.type = 123;
	}
	

}
