package estates;

interface IBuilding {
	
	public String getBiuldingInfo();

}
