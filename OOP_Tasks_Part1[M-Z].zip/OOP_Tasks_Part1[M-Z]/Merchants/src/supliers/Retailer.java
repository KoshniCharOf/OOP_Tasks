package supliers;


public class Retailer extends Supplier {

	@Override
	public double getDiscount() {
		return 1;
	}

}
