/**
 * 
 */
package supliers;

/**
 * 
 *
 */
public class Wholesale extends Supplier {



	
	@Override
	public double getDiscount() {
		
		return 0.85;
	}

}
